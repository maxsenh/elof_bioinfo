import numpy as np
from sklearn import cluster

# Load the data from the file, numbers are separated by commas.
data = np.loadtxt('expression_parsed.dat', delimiter=',')

# Start the clustering object
km = cluster.KMeans(3)

# Find the centroids and predict to which cluster would they belong on the same data.
indexes = km.fit_predict(data)
print(indexes)

